<template>
  <div
    class="min-h-screen overflow-x-hidden bg-gray-50 text-gray-800 dark:bg-gray-900 dark:text-gray-100"
  >
    <RouterView />
  </div>
</template>
